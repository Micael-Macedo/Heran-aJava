/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade.herança.medico;

/**
 *
 * @author Treinamento
 */
public class AtvMedico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Medico medico = new Medico();
        medico.setCRM("Sla");
        medico.setIdade(30);
        medico.setNome("Isaias");
        medico.setSalario(5000);
        medico.setMedicoAposentado();
        
        System.out.println(medico.getValorAposentadoria());
        
        if(medico.getMedicoAposentado() == true){
            System.out.println("Medico Aposentado");
        }else{
            System.out.println("Medico em Serviço");
        }
        
        MedicoAuxiliar mA = new MedicoAuxiliar();
        mA.setCRM("Sla3");
        mA.setIdade(60);
        mA.setNome("Micael");
        mA.setSalario(5000);
        mA.setMedicoAposentado();
        
        System.out.println(mA.getValorAposentadoria());
        if(mA.getMedicoAposentado() == true){
            System.out.println("Medico Aposentado");
        }else{
            System.out.println("Medico em Serviço");
        }
        
        MedicoCirurgiao mC = new MedicoCirurgiao();
        mC.setCRM("Sla");
        mC.setIdade(80);
        mC.setNome("Bruno");
        mC.setSalario(5000);
        mC.setMedicoAposentado();
        
        System.out.println(mC.getValorAposentadoria());
        System.out.println(mA.getValorAposentadoria());
        if(mC.getMedicoAposentado() == true){
            System.out.println("Medico Aposentado");
        }else{
            System.out.println("Medico em Serviço");
        }
    }
    
}
