/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade.herança.medico;

/**
 *
 * @author Treinamento
 */
public class MedicoCirurgiao extends Medico{
    
    @Override
    public void setMedicoAposentado(){
        if(this.idade > 50){
            this.statusAposentado = true;
        }else{
            this.statusAposentado = false;
        }
    }
     
    @Override
    public double getValorAposentadoria(){
        return super.getValorAposentadoria() + 800;
    }
}
